

def construct_greeting(name):
    return f"Hello {name}"
